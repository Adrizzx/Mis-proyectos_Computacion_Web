<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $hobbies = $_POST["hobbies"];

    echo '<div class="alert alert-success" role="alert">';
    echo '<h5 class="alert-heading">¡Datos recibidos exitosamente!</h5>';
    echo '<p><strong>Email:</strong> ' . $email . '</p>';
    echo '<p><strong>Hobbies:</strong> ' . $hobbies . '</p>';
    echo '<hr>';
    echo '<p class="mb-0"> Gracias por compartir tus hobbies con nosotros </p>';
    echo '</div>';
}
?>