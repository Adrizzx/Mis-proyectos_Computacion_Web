<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'crud_usuario';
$username = 'crud_usuario';
$password = '12345';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);
    
    if (!$data || !isset($data['id']) || !isset($data['tabla'])) {
        echo json_encode(['success' => false, 'error' => 'Faltan datos']);
        exit;
    }
    
    $id = (int)$data['id'];
    $tabla = $data['tabla'];
    
    $tablasPermitidas = ['usuarios', 'productos', 'estudiantes', 'empleados', 'libros', 'vehiculos'];
    
    if (!in_array($tabla, $tablasPermitidas)) {
        echo json_encode(['success' => false, 'error' => 'Tabla no permitida']);
        exit;
    }
    
    $sql = "SELECT * FROM $tabla WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $registro = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($registro) {
        echo json_encode([
            'success' => true,
            'registro' => $registro,
            'tabla' => $tabla
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Registro no encontrado'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>