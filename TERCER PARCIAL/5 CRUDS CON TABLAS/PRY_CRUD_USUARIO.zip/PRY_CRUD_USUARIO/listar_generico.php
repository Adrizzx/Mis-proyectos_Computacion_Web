<?php
require 'db.php';

$tabla = $_GET['tabla'] ?? 'usuarios';

// Configuración para cada tabla
$config = [
    'usuarios' => [
        'titulo' => '👥 Lista de Usuarios',
        'columnas' => ['ID', 'Nombre', 'Email', 'Edad'],
        'campos_edit' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre'],
            'email' => ['tipo' => 'email', 'label' => 'Email'],
            'edad' => ['tipo' => 'number', 'label' => 'Edad']
        ]
    ],
    'productos' => [
        'titulo' => '📦 Lista de Productos',
        'columnas' => ['ID', 'Nombre', 'Descripción', 'Precio', 'Stock', 'Categoría'],
        'campos_edit' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre'],
            'descripcion' => ['tipo' => 'textarea', 'label' => 'Descripción'],
            'precio' => ['tipo' => 'number', 'label' => 'Precio', 'step' => '0.01'],
            'stock' => ['tipo' => 'number', 'label' => 'Stock'],
            'categoria' => ['tipo' => 'text', 'label' => 'Categoría']
        ]
    ],
    'estudiantes' => [
        'titulo' => '🎓 Lista de Estudiantes',
        'columnas' => ['ID', 'Nombre', 'Apellido', 'Código', 'Carrera', 'Semestre', 'Teléfono'],
        'campos_edit' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre'],
            'apellido' => ['tipo' => 'text', 'label' => 'Apellido'],
            'codigo_estudiante' => ['tipo' => 'text', 'label' => 'Código'],
            'carrera' => ['tipo' => 'text', 'label' => 'Carrera'],
            'semestre' => ['tipo' => 'number', 'label' => 'Semestre'],
            'telefono' => ['tipo' => 'text', 'label' => 'Teléfono']
        ]
    ],
    'empleados' => [
        'titulo' => '👔 Lista de Empleados',
        'columnas' => ['ID', 'Nombre', 'Apellido', 'Cédula', 'Cargo', 'Salario', 'Departamento', 'F. Contratación'],
        'campos_edit' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre'],
            'apellido' => ['tipo' => 'text', 'label' => 'Apellido'],
            'cedula' => ['tipo' => 'text', 'label' => 'Cédula'],
            'cargo' => ['tipo' => 'text', 'label' => 'Cargo'],
            'salario' => ['tipo' => 'number', 'label' => 'Salario', 'step' => '0.01'],
            'departamento' => ['tipo' => 'text', 'label' => 'Departamento'],
            'fecha_contratacion' => ['tipo' => 'date', 'label' => 'Fecha Contratación']
        ]
    ],
    'libros' => [
        'titulo' => '📚 Lista de Libros',
        'columnas' => ['ID', 'Título', 'Autor', 'ISBN', 'Género', 'Editorial', 'Año'],
        'campos_edit' => [
            'titulo' => ['tipo' => 'text', 'label' => 'Título'],
            'autor' => ['tipo' => 'text', 'label' => 'Autor'],
            'isbn' => ['tipo' => 'text', 'label' => 'ISBN'],
            'genero' => ['tipo' => 'text', 'label' => 'Género'],
            'editorial' => ['tipo' => 'text', 'label' => 'Editorial'],
            'año_publicacion' => ['tipo' => 'number', 'label' => 'Año Publicación']
        ]
    ],
    'vehiculos' => [
        'titulo' => '🚗 Lista de Vehículos',
        'columnas' => ['ID', 'Marca', 'Modelo', 'Año', 'Placa', 'Color', 'Tipo', 'Kilometraje'],
        'campos_edit' => [
            'marca' => ['tipo' => 'text', 'label' => 'Marca'],
            'modelo' => ['tipo' => 'text', 'label' => 'Modelo'],
            'año' => ['tipo' => 'number', 'label' => 'Año'],
            'placa' => ['tipo' => 'text', 'label' => 'Placa'],
            'color' => ['tipo' => 'text', 'label' => 'Color'],
            'tipo' => ['tipo' => 'text', 'label' => 'Tipo'],
            'kilometraje' => ['tipo' => 'number', 'label' => 'Kilometraje']
        ]
    ]
];

if (!isset($config[$tabla])) {
    header("Location: index.html");
    exit();
}

$tablaConfig = $config[$tabla];

// Consultar los registros
$sql = "SELECT * FROM $tabla";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $tablaConfig['titulo']; ?></title>
  <link rel="stylesheet" href="PUBLIC/bootstrap-5.3.5-dist/css/bootstrap.min.css" />
</head>
<body>
  <div class="container py-5">
    <h1><?php echo $tablaConfig['titulo']; ?></h1>
    
    <div class="table-responsive">
      <table class="table table-striped tabla-registros">
        <thead>
          <tr>
            <?php foreach ($tablaConfig['columnas'] as $columna): ?>
              <th><?php echo $columna; ?></th>
            <?php endforeach; ?>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($registros as $registro): ?>
            <tr>
              <?php foreach ($registro as $campo => $valor): ?>
                <?php if ($campo !== 'fecha_registro'): ?>
                  <td>
                    <?php 
                    if ($campo === 'precio' || $campo === 'salario') {
                        echo '$' . number_format($valor, 2);
                    } elseif ($campo === 'descripcion' && strlen($valor) > 50) {
                        echo substr($valor, 0, 50) . '...';
                    } else {
                        echo htmlspecialchars($valor);
                    }
                    ?>
                  </td>
                <?php endif; ?>
              <?php endforeach; ?>
              <td>
                <button
                  type="button"
                  class="btn btn-warning btn-sm btn-editar"
                  data-id="<?php echo $registro['id']; ?>"
                  data-tabla="<?php echo $tabla; ?>"
                >
                  Editar
                </button>
                <a href="eliminar_generico.php?tabla=<?php echo $tabla; ?>&id=<?php echo $registro['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?')">Eliminar</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    
    <div class="mt-3">
      <a href="index.html" class="btn btn-secondary">Volver al inicio</a>
      <a href="crear_generico.php?tabla=<?php echo $tabla; ?>" class="btn btn-success">Crear Nuevo</a>
    </div>
  </div>

  <!-- Modal Editar -->
  <div class="modal fade" id="modalEditar" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Editar Registro</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="loading" style="display:none;" class="text-center">
            <div class="spinner-border" role="status">
              <span class="visually-hidden">Cargando...</span>
            </div>
          </div>
          <form id="formEditar">
            <input type="hidden" id="registroId">
            <input type="hidden" id="tablaActual">
            <div id="camposFormulario">
              <!-- Los campos se generan dinámicamente -->
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="button" class="btn btn-primary" id="guardarCambios">Guardar</button>
        </div>
      </div>
    </div>
  </div>

  <script src="PUBLIC/bootstrap-5.3.5-dist/js/bootstrap.min.js"></script>
  <script>
    const modalEditar = new bootstrap.Modal(document.getElementById('modalEditar'));
    const tablaRegistros = document.querySelector('.tabla-registros');
    
    // Configuración de campos para cada tabla
    const configCampos = <?php echo json_encode(array_map(function($config) { return $config['campos_edit']; }, $config)); ?>;
    
    tablaRegistros.addEventListener('click', function(event) {
      if (event.target.classList.contains('btn-editar')) {
        const id = event.target.dataset.id;
        const tabla = event.target.dataset.tabla;
        const loading = document.getElementById('loading');
        
        console.log('Buscando:', {id, tabla});
        loading.style.display = 'block';
        
        fetch('buscarRegistroPorId.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ id: id, tabla: tabla })
        })
        .then(response => {
          console.log('Response status:', response.status);
          if (!response.ok) {
            throw new Error('HTTP ' + response.status);
          }
          return response.text();
        })
        .then(text => {
          console.log('Raw response:', text);
          loading.style.display = 'none';
          
          const data = JSON.parse(text);
          console.log('Parsed data:', data);
          
          if (data.success) {
            // Llenar el formulario
            document.getElementById('registroId').value = data.registro.id;
            document.getElementById('tablaActual').value = data.tabla;
            
            // Generar campos dinámicamente
            const camposContainer = document.getElementById('camposFormulario');
            camposContainer.innerHTML = '';
            
            const campos = configCampos[tabla];
            Object.keys(campos).forEach(campo => {
              const config = campos[campo];
              const valor = data.registro[campo] || '';
              
              const div = document.createElement('div');
              div.className = 'mb-3';
              
              if (config.tipo === 'textarea') {
                div.innerHTML = `
                  <label for="${campo}" class="form-label">${config.label}:</label>
                  <textarea class="form-control" id="${campo}" name="${campo}">${valor}</textarea>
                `;
              } else {
                const step = config.step ? `step="${config.step}"` : '';
                div.innerHTML = `
                  <label for="${campo}" class="form-label">${config.label}:</label>
                  <input type="${config.tipo}" class="form-control" id="${campo}" name="${campo}" value="${valor}" ${step}>
                `;
              }
              
              camposContainer.appendChild(div);
            });
            
            modalEditar.show();
          } else {
            alert('Error: ' + data.error);
          }
        })
        .catch(error => {
          loading.style.display = 'none';
          console.error('Fetch error:', error);
          alert('Error: ' + error.message);
        });
      }
    });

    document.getElementById('guardarCambios').addEventListener('click', function() {
      alert('Función actualizar pendiente de implementar');
      modalEditar.hide();
    });
  </script>
</body>
</html>