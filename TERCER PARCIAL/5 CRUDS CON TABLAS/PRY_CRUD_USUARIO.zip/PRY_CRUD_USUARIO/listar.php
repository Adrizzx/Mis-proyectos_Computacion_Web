<?php
// Conexión sin echo que interfiera
$host = 'localhost';
$dbname = 'crud_usuario';
$username = 'crud_usuario';
$password = '12345';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión");
}

// Consultar los usuarios
$sql = "SELECT * FROM usuarios";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lista de Usuarios</title>
  <link rel="stylesheet" href="PUBLIC/bootstrap-5.3.5-dist/css/bootstrap.min.css" />
</head>
<body>
  <div class="container py-5">
    <h1>Lista de Usuarios</h1>
    <table class="table tabla-usuarios">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Email</th>
          <th>Edad</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($usuarios as $usuario): ?>
          <tr>
            <td><?php echo $usuario['id']; ?></td>
            <td><?php echo $usuario['nombre']; ?></td>
            <td><?php echo $usuario['email']; ?></td>
            <td><?php echo $usuario['edad']; ?></td>
            <td>
              <button
                type="button"
                class="btn btn-warning btn-sm btn-editar-usuario"
                data-id="<?php echo $usuario['id']; ?>"
              >
              Editar
              </button>
              
              <button
                type="button"
                class="btn btn-danger btn-sm btn-eliminar-usuario"
                data-id="<?php echo $usuario['id']; ?>"
              >
              Eliminar 
              </button>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div class="mt-3">
      <a href="index.html" class="btn btn-secondary">Volver al inicio</a>
    </div>
  </div>
  
  <!-- Modal -->
  <div class="modal fade" id="modalUsuario" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Editar Usuario</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="loading" style="display:none;" class="text-center mb-3">
            <div class="spinner-border" role="status"></div>
            <div>Cargando...</div>
          </div>
          <form id="formEditarUsuario">
            <input type="hidden" id="usuarioId">
            
            <div class="mb-3">
              <label for="usuarioNombre" class="form-label">Nombre:</label>
              <input type="text" class="form-control" id="usuarioNombre" required>
            </div>
            
            <div class="mb-3">
              <label for="usuarioEmail" class="form-label">Email:</label>
              <input type="email" class="form-control" id="usuarioEmail" required>
            </div>
            
            <div class="mb-3">
              <label for="usuarioEdad" class="form-label">Edad:</label>
              <input type="number" class="form-control" id="usuarioEdad" required>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="button" class="btn btn-primary" id="guardarCambios">Guardar</button>
        </div>
      </div>
    </div>
  </div>

  <script src="PUBLIC/bootstrap-5.3.5-dist/js/bootstrap.min.js"></script>
  <script>
    const modalUsuario = new bootstrap.Modal(document.getElementById('modalUsuario'));
    const tablaUsuarios = document.querySelector('.tabla-usuarios');
    
    tablaUsuarios.addEventListener('click', function(event) {
      if (event.target.classList.contains('btn-editar-usuario')) {
        const id = event.target.dataset.id;
        const loading = document.getElementById('loading');
        
        console.log('Buscando usuario ID:', id);
        loading.style.display = 'block';
        
        // Usar el nuevo archivo genérico
        fetch('buscarRegistroPorId.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ id: id, tabla: 'usuarios' })
        })
        .then(response => {
          console.log('Response status:', response.status);
          if (!response.ok) {
            throw new Error('HTTP ' + response.status);
          }
          return response.text();
        })
        .then(text => {
          console.log('Raw response:', text);
          loading.style.display = 'none';
          
          const data = JSON.parse(text);
          console.log('Parsed data:', data);
          
          if (data.success) {
            document.getElementById('usuarioId').value = data.registro.id;
            document.getElementById('usuarioNombre').value = data.registro.nombre;
            document.getElementById('usuarioEmail').value = data.registro.email;
            document.getElementById('usuarioEdad').value = data.registro.edad;
            
            modalUsuario.show();
          } else {
            alert('Error: ' + data.error);
          }
        })
        .catch(error => {
          loading.style.display = 'none';
          console.error('Fetch error:', error);
          alert('Error: ' + error.message);
        });
      }
      
      if (event.target.classList.contains('btn-eliminar-usuario')) {
        const id = event.target.dataset.id;
        if (confirm('¿Eliminar usuario?')) {
          window.location.href = 'eliminar.php?id=' + id;
        }
      }
    });

    document.getElementById('guardarCambios').addEventListener('click', function() {
      const id = document.getElementById('usuarioId').value;
      const nombre = document.getElementById('usuarioNombre').value;
      const email = document.getElementById('usuarioEmail').value;
      const edad = document.getElementById('usuarioEdad').value;
      
      // Validación básica
      if (!nombre || !email || !edad) {
        alert('Todos los campos son requeridos');
        return;
      }
      
      console.log('Guardando cambios:', {id, nombre, email, edad});
      
      fetch('actualizarUsuario.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id: id,
          nombre: nombre,
          email: email,
          edad: edad
        })
      })
      .then(response => response.text())
      .then(text => {
        console.log('Respuesta cruda:', text);
        
        // Si hay respuesta (aunque sea null), la actualización fue exitosa
        alert('Usuario actualizado correctamente');
        modalUsuario.hide();
        window.location.reload();
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error al actualizar: ' + error.message);
      });
    });
  </script>
</body>
</html>