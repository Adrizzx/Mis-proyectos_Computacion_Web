<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tabla = $_POST['tabla'];
    
    // Configuración de campos para cada tabla (excluir id y fecha_registro)
    $camposConfig = [
        'usuarios' => ['nombre', 'email', 'edad'],
        'productos' => ['nombre', 'descripcion', 'precio', 'stock', 'categoria'],
        'estudiantes' => ['nombre', 'apellido', 'codigo_estudiante', 'carrera', 'semestre', 'telefono'],
        'empleados' => ['nombre', 'apellido', 'cedula', 'cargo', 'salario', 'departamento', 'fecha_contratacion'],
        'libros' => ['titulo', 'autor', 'isbn', 'genero', 'editorial', 'año_publicacion'],
        'vehiculos' => ['marca', 'modelo', 'año', 'placa', 'color', 'tipo', 'kilometraje']
    ];
    
    // Verificar si la tabla existe en la configuración
    if (!isset($camposConfig[$tabla])) {
        die("Tabla no válida");
    }
    
    $campos = $camposConfig[$tabla];
    
    // Construir la consulta SQL dinámicamente
    $columnas = implode(', ', $campos);
    $placeholders = ':' . implode(', :', $campos);
    $sql = "INSERT INTO $tabla ($columnas) VALUES ($placeholders)";
    
    try {
        $stmt = $pdo->prepare($sql);
        
        // Vincular los parámetros dinámicamente
        foreach ($campos as $campo) {
            $valor = $_POST[$campo] ?? null;
            $stmt->bindValue(":$campo", $valor);
        }
        
        if ($stmt->execute()) {
            echo "<script>alert('Registro creado exitosamente'); window.location.href='index.html';</script>";
        } else {
            echo "<script>alert('Error al crear el registro'); window.history.back();</script>";
        }
        
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "'); window.history.back();</script>";
    }
}
?>