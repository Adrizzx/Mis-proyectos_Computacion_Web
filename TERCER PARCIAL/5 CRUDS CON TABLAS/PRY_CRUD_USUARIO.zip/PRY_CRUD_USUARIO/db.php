<?php
$host = 'localhost';
$dbname = 'crud_usuario';
$username = 'crud_usuario';
$password = '12345';
$charset = 'utf8';
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // NO ECHO - esto interfería con el JSON
} catch (PDOException $e) {
    // Solo mostrar error si se accede directamente
    if (basename($_SERVER['PHP_SELF']) == 'db.php') {
        echo "Error de conexión: " . $e->getMessage();
    }
}
?>