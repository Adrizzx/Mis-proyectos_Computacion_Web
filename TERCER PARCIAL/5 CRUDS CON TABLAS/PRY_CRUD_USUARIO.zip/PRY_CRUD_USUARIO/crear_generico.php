<?php
// Obtener la tabla desde el parámetro URL
$tabla = $_GET['tabla'] ?? 'usuarios';

// Configuración de campos para cada tabla
$config = [
    'usuarios' => [
        'titulo' => '👥 Crear Usuario',
        'campos' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre', 'required' => true],
            'email' => ['tipo' => 'email', 'label' => 'Email', 'required' => true],
            'edad' => ['tipo' => 'number', 'label' => 'Edad', 'required' => true]
        ]
    ],
    'productos' => [
        'titulo' => '📦 Crear Producto',
        'campos' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre', 'required' => true],
            'descripcion' => ['tipo' => 'textarea', 'label' => 'Descripción', 'required' => false],
            'precio' => ['tipo' => 'number', 'label' => 'Precio', 'required' => true, 'step' => '0.01'],
            'stock' => ['tipo' => 'number', 'label' => 'Stock', 'required' => true],
            'categoria' => ['tipo' => 'text', 'label' => 'Categoría', 'required' => false]
        ]
    ],
    'estudiantes' => [
        'titulo' => '🎓 Crear Estudiante',
        'campos' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre', 'required' => true],
            'apellido' => ['tipo' => 'text', 'label' => 'Apellido', 'required' => true],
            'codigo_estudiante' => ['tipo' => 'text', 'label' => 'Código Estudiante', 'required' => true],
            'carrera' => ['tipo' => 'text', 'label' => 'Carrera', 'required' => false],
            'semestre' => ['tipo' => 'number', 'label' => 'Semestre', 'required' => false],
            'telefono' => ['tipo' => 'text', 'label' => 'Teléfono', 'required' => false]
        ]
    ],
    'empleados' => [
        'titulo' => '👔 Crear Empleado',
        'campos' => [
            'nombre' => ['tipo' => 'text', 'label' => 'Nombre', 'required' => true],
            'apellido' => ['tipo' => 'text', 'label' => 'Apellido', 'required' => true],
            'cedula' => ['tipo' => 'text', 'label' => 'Cédula', 'required' => true],
            'cargo' => ['tipo' => 'text', 'label' => 'Cargo', 'required' => false],
            'salario' => ['tipo' => 'number', 'label' => 'Salario', 'required' => false, 'step' => '0.01'],
            'departamento' => ['tipo' => 'text', 'label' => 'Departamento', 'required' => false],
            'fecha_contratacion' => ['tipo' => 'date', 'label' => 'Fecha Contratación', 'required' => false]
        ]
    ],
    'libros' => [
        'titulo' => '📚 Crear Libro',
        'campos' => [
            'titulo' => ['tipo' => 'text', 'label' => 'Título', 'required' => true],
            'autor' => ['tipo' => 'text', 'label' => 'Autor', 'required' => true],
            'isbn' => ['tipo' => 'text', 'label' => 'ISBN', 'required' => false],
            'genero' => ['tipo' => 'text', 'label' => 'Género', 'required' => false],
            'editorial' => ['tipo' => 'text', 'label' => 'Editorial', 'required' => false],
            'año_publicacion' => ['tipo' => 'number', 'label' => 'Año Publicación', 'required' => false]
        ]
    ],
    'vehiculos' => [
        'titulo' => '🚗 Crear Vehículo',
        'campos' => [
            'marca' => ['tipo' => 'text', 'label' => 'Marca', 'required' => true],
            'modelo' => ['tipo' => 'text', 'label' => 'Modelo', 'required' => true],
            'año' => ['tipo' => 'number', 'label' => 'Año', 'required' => true],
            'placa' => ['tipo' => 'text', 'label' => 'Placa', 'required' => true],
            'color' => ['tipo' => 'text', 'label' => 'Color', 'required' => false],
            'tipo' => ['tipo' => 'text', 'label' => 'Tipo', 'required' => false],
            'kilometraje' => ['tipo' => 'number', 'label' => 'Kilometraje', 'required' => false]
        ]
    ]
];

// Verificar si la tabla existe
if (!isset($config[$tabla])) {
    header("Location: index.html");
    exit();
}

$tablaConfig = $config[$tabla];
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $tablaConfig['titulo']; ?></title>
  <link rel="stylesheet" href="PUBLIC/bootstrap-5.3.5-dist/css/bootstrap.min.css" />
</head>
<body>
  <div class="container py-5">
    <h1><?php echo $tablaConfig['titulo']; ?></h1>
    
    <form action="guardar_generico.php" method="post">
      <input type="hidden" name="tabla" value="<?php echo $tabla; ?>">
      
      <?php foreach ($tablaConfig['campos'] as $campo => $propiedades): ?>
        <div class="mb-3">
          <label for="<?php echo $campo; ?>" class="form-label"><?php echo $propiedades['label']; ?></label>
          
          <?php if ($propiedades['tipo'] == 'textarea'): ?>
            <textarea class="form-control" id="<?php echo $campo; ?>" name="<?php echo $campo; ?>" rows="3" <?php echo $propiedades['required'] ? 'required' : ''; ?>></textarea>
          <?php else: ?>
            <input type="<?php echo $propiedades['tipo']; ?>" 
                   class="form-control" 
                   id="<?php echo $campo; ?>" 
                   name="<?php echo $campo; ?>" 
                   <?php echo isset($propiedades['step']) ? 'step="'.$propiedades['step'].'"' : ''; ?>
                   <?php echo $propiedades['required'] ? 'required' : ''; ?>>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      
      <button type="submit" class="btn btn-primary">Crear</button>
    </form>
    
    <div class="mt-3">
      <a href="index.html" class="btn btn-secondary">Volver al inicio</a>
    </div>
  </div>
</body>
</html>