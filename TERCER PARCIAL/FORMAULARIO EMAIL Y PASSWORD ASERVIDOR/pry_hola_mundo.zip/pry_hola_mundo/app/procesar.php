<?php

   echo  $_POST['txt_email'];
   echo "<br>";
    echo  $_POST['txt_password'];
?>
