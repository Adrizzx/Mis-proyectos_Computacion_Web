<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
  if ($method === 'GET') {
    $q = trim($_GET['q'] ?? '');
    if ($q !== '') {
      $like = "%$q%";
      $st = $pdo->prepare("SELECT id, nombre, correo, telefono, fecha_nacimiento FROM pacientes
                           WHERE nombre LIKE ? OR correo LIKE ? OR telefono LIKE ?
                           ORDER BY id DESC");
      $st->execute([$like, $like, $like]);
    } else {
      $st = $pdo->query("SELECT id, nombre, correo, telefono, fecha_nacimiento FROM pacientes ORDER BY id DESC");
    }
    echo json_encode($st->fetchAll());
    exit;
  }

  $input = json_decode(file_get_contents('php://input'), true) ?? [];

  if ($method === 'POST') {
    $nombre = trim($input['nombre'] ?? '');
    $correo = trim($input['correo'] ?? '');
    $telefono = trim($input['telefono'] ?? '');
    $fnac = trim($input['fecha_nacimiento'] ?? '');

    if ($nombre === '' || $correo === '') { http_response_code(400); echo json_encode(['error'=>'Nombre y correo son obligatorios']); exit; }
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) { http_response_code(400); echo json_encode(['error'=>'Correo no válido']); exit; }

    $st = $pdo->prepare("INSERT INTO pacientes (nombre, correo, telefono, fecha_nacimiento) VALUES (?, ?, ?, ?)");
    $st->execute([$nombre, $correo, $telefono, $fnac ?: null]);

    $id = $pdo->lastInsertId();
    $st = $pdo->prepare("SELECT id, nombre, correo, telefono, fecha_nacimiento FROM pacientes WHERE id=?");
    $st->execute([$id]);
    echo json_encode(['ok'=>true, 'paciente'=>$st->fetch()]);
    exit;
  }

  if ($method === 'PUT') {
    $id = (int)($input['id'] ?? 0);
    $nombre = trim($input['nombre'] ?? '');
    $correo = trim($input['correo'] ?? '');
    $telefono = trim($input['telefono'] ?? '');
    $fnac = trim($input['fecha_nacimiento'] ?? '');

    if ($id <= 0 || $nombre === '' || $correo === '') { http_response_code(400); echo json_encode(['error'=>'ID, nombre y correo son obligatorios']); exit; }
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) { http_response_code(400); echo json_encode(['error'=>'Correo no válido']); exit; }

    $st = $pdo->prepare("UPDATE pacientes SET nombre=?, correo=?, telefono=?, fecha_nacimiento=? WHERE id=?");
    $st->execute([$nombre, $correo, $telefono, $fnac ?: null, $id]);
    echo json_encode(['ok'=>$st->rowCount()>=0]);
    exit;
  }

  if ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'] ?? '', $p);
    $id = (int)($p['id'] ?? 0);
    if ($id <= 0) { http_response_code(400); echo json_encode(['error'=>'ID requerido']); exit; }
    $st = $pdo->prepare("DELETE FROM pacientes WHERE id=?");
    $st->execute([$id]);
    echo json_encode(['ok'=>$st->rowCount()>0]);
    exit;
  }

  http_response_code(405);
  echo json_encode(['error'=>'Método no permitido']);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error'=>'Error en servidor']);
  error_log('PACIENTES ERROR: '.$e->getMessage());
}
