<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

function calcular_y_validar(PDO $pdo, string $fecha, string $hora_inicio, string $hora_fin, int $medico_id): array {
  if (!$fecha || !$hora_inicio || !$hora_fin || $medico_id <= 0) throw new Exception('Datos incompletos de la cita');

  $ini = DateTime::createFromFormat('Y-m-d H:i', "$fecha $hora_inicio");
  $fin = DateTime::createFromFormat('Y-m-d H:i', "$fecha $hora_fin");
  if (!$ini || !$fin) throw new Exception('Formato de fecha/hora inválido (usa YYYY-MM-DD y HH:MM)');

  if ($fin <= $ini) throw new Exception('La hora fin debe ser mayor que la hora inicio');

  $ahora = new DateTime('now');
  if ($ini < $ahora) throw new Exception('No se permiten citas en el pasado');

  $durMin = (int) round(($fin->getTimestamp() - $ini->getTimestamp()) / 60);

  $st = $pdo->prepare("SELECT tarifa_por_hora FROM medicos WHERE id=?");
  $st->execute([$medico_id]);
  $row = $st->fetch();
  if (!$row) throw new Exception('Médico no encontrado');

  $tarifa = (float)$row['tarifa_por_hora'];
  $costo = round(($durMin / 60) * $tarifa, 2);

  return [$durMin, $costo];
}

$method = $_SERVER['REQUEST_METHOD'];

try {
  if ($method === 'GET') {
    $st = $pdo->query("
      SELECT c.id,
             c.paciente_id, p.nombre AS paciente,
             c.medico_id,   m.nombre AS medico,
             m.especialidad, m.tarifa_por_hora,
             c.fecha, c.hora_inicio, c.hora_fin,
             c.duracion, c.costo_total, c.estado
      FROM citas c
      JOIN pacientes p ON p.id = c.paciente_id
      JOIN medicos m   ON m.id = c.medico_id
      ORDER BY c.fecha DESC, c.hora_inicio DESC
    ");
    echo json_encode($st->fetchAll());
    exit;
  }

  $input = json_decode(file_get_contents('php://input'), true) ?? [];

  if ($method === 'POST') {
    $paciente_id = (int)($input['paciente_id'] ?? 0);
    $medico_id   = (int)($input['medico_id'] ?? 0);
    $fecha       = trim($input['fecha'] ?? '');
    $hora_inicio = trim($input['hora_inicio'] ?? '');
    $hora_fin    = trim($input['hora_fin'] ?? '');
    $estado      = trim($input['estado'] ?? 'programada');

    if ($paciente_id<=0 || $medico_id<=0) { http_response_code(400); echo json_encode(['error'=>'Paciente y médico son obligatorios']); exit; }

    $s = $pdo->prepare("SELECT id FROM pacientes WHERE id=?"); $s->execute([$paciente_id]); if(!$s->fetch()){ http_response_code(400); echo json_encode(['error'=>'Paciente no encontrado']); exit; }
    $s = $pdo->prepare("SELECT id FROM medicos WHERE id=?");   $s->execute([$medico_id]);   if(!$s->fetch()){ http_response_code(400); echo json_encode(['error'=>'Médico no encontrado']); exit; }

    try { [$dur, $cost] = calcular_y_validar($pdo, $fecha, $hora_inicio, $hora_fin, $medico_id); }
    catch (Exception $e) { http_response_code(400); echo json_encode(['error'=>$e->getMessage()]); exit; }

    $st = $pdo->prepare("INSERT INTO citas (paciente_id, medico_id, fecha, hora_inicio, hora_fin, duracion, costo_total, estado)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $st->execute([$paciente_id, $medico_id, $fecha, $hora_inicio, $hora_fin, $dur, $cost, $estado]);
    echo json_encode(['ok'=>true, 'id'=>$pdo->lastInsertId(), 'duracion'=>$dur, 'costo_total'=>$cost, 'estado'=>$estado]);
    exit;
  }

  if ($method === 'PUT') {
    $id          = (int)($input['id'] ?? 0);
    $paciente_id = (int)($input['paciente_id'] ?? 0);
    $medico_id   = (int)($input['medico_id'] ?? 0);
    $fecha       = trim($input['fecha'] ?? '');
    $hora_inicio = trim($input['hora_inicio'] ?? '');
    $hora_fin    = trim($input['hora_fin'] ?? '');
    $estado      = trim($input['estado'] ?? 'programada');

    if ($id<=0 || $paciente_id<=0 || $medico_id<=0) { http_response_code(400); echo json_encode(['error'=>'ID, paciente y médico obligatorios']); exit; }

    try { [$dur, $cost] = calcular_y_validar($pdo, $fecha, $hora_inicio, $hora_fin, $medico_id); }
    catch (Exception $e) { http_response_code(400); echo json_encode(['error'=>$e->getMessage()]); exit; }

    $st = $pdo->prepare("UPDATE citas SET paciente_id=?, medico_id=?, fecha=?, hora_inicio=?, hora_fin=?, duracion=?, costo_total=?, estado=? WHERE id=?");
    $st->execute([$paciente_id, $medico_id, $fecha, $hora_inicio, $hora_fin, $dur, $cost, $estado, $id]);
    echo json_encode(['ok'=>$st->rowCount()>=0, 'duracion'=>$dur, 'costo_total'=>$cost, 'estado'=>$estado]);
    exit;
  }

  if ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'] ?? '', $p);
    $id = (int)($p['id'] ?? 0);
    if ($id<=0){ http_response_code(400); echo json_encode(['error'=>'ID requerido']); exit; }
    $st = $pdo->prepare("DELETE FROM citas WHERE id=?");
    $st->execute([$id]);
    echo json_encode(['ok'=>$st->rowCount()>0]);
    exit;
  }

  http_response_code(405);
  echo json_encode(['error'=>'Método no permitido']);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error'=>'Error en servidor']);
  error_log('CITAS ERROR: '.$e->getMessage());
}
