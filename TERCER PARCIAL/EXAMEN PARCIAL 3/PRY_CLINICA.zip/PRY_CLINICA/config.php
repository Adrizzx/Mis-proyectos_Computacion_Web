<?php
return [
  'host'     => 'localhost',
  'dbname'   => 'clinica_examen', 
  'username' => 'root',
  'password' => '',
  'charset'  => 'utf8mb4',
  'timezone' => 'America/Guayaquil'
];
