<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
  if ($method === 'GET') {
    $st = $pdo->query("SELECT id, nombre, especialidad, tarifa_por_hora FROM medicos ORDER BY id DESC");
    echo json_encode($st->fetchAll());
    exit;
  }

  $input = json_decode(file_get_contents('php://input'), true) ?? [];

  if ($method === 'POST') {
    $nombre = trim($input['nombre'] ?? '');
    $esp = trim($input['especialidad'] ?? '');
    $tarifa = (float)($input['tarifa_por_hora'] ?? -1);

    if ($nombre === '' || $esp === '' || $tarifa < 0) { http_response_code(400); echo json_encode(['error'=>'Nombre, especialidad y tarifa son obligatorios']); exit; }

    $st = $pdo->prepare("INSERT INTO medicos (nombre, especialidad, tarifa_por_hora) VALUES (?, ?, ?)");
    $st->execute([$nombre, $esp, $tarifa]);

    $id = $pdo->lastInsertId();
    $st = $pdo->prepare("SELECT id, nombre, especialidad, tarifa_por_hora FROM medicos WHERE id=?");
    $st->execute([$id]);
    echo json_encode(['ok'=>true, 'medico'=>$st->fetch()]);
    exit;
  }

  if ($method === 'PUT') {
    $id = (int)($input['id'] ?? 0);
    $nombre = trim($input['nombre'] ?? '');
    $esp = trim($input['especialidad'] ?? '');
    $tarifa = (float)($input['tarifa_por_hora'] ?? -1);

    if ($id<=0 || $nombre === '' || $esp === '' || $tarifa < 0) { http_response_code(400); echo json_encode(['error'=>'Todos los campos son obligatorios']); exit; }

    $st = $pdo->prepare("UPDATE medicos SET nombre=?, especialidad=?, tarifa_por_hora=? WHERE id=?");
    $st->execute([$nombre, $esp, $tarifa, $id]);
    echo json_encode(['ok'=>$st->rowCount()>=0]);
    exit;
  }

  if ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'] ?? '', $p);
    $id = (int)($p['id'] ?? 0);
    if ($id<=0){ http_response_code(400); echo json_encode(['error'=>'ID requerido']); exit; }
    $st = $pdo->prepare("DELETE FROM medicos WHERE id=?");
    $st->execute([$id]);
    echo json_encode(['ok'=>$st->rowCount()>0]);
    exit;
  }

  http_response_code(405);
  echo json_encode(['error'=>'Método no permitido']);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error'=>'Error en servidor']);
  error_log('MEDICOS ERROR: '.$e->getMessage());
}
