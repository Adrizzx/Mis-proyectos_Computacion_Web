<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Método no permitido";
    exit;
}

if (!isset($_POST['numero1']) || !isset($_POST['numero2'])) {
    echo "Faltan datos requeridos";
    exit;
}

$numero1 = $_POST['numero1'];
$numero2 = $_POST['numero2'];

if (!is_numeric($numero1) || !is_numeric($numero2)) {
    echo "Por favor ingresa números válidos";
    exit;
}

$num1 = floatval($numero1);
$num2 = floatval($numero2);
$resultado = $num1 + $num2;

$resultado_formateado = (floor($resultado) == $resultado) ? 
    number_format($resultado, 0) : 
    number_format($resultado, 2);

echo "<div class='text-center'>";
echo "<h4 class='text-primary mb-3'>Resultado de la Operación</h4>";
echo "<div class='fs-5 mb-2'>";
echo "<span class='badge bg-light text-dark me-2'>" . number_format($num1, ($num1 == floor($num1) ? 0 : 2)) . "</span>";
echo "<i class='fas fa-plus text-primary mx-2'></i>";
echo "<span class='badge bg-light text-dark me-2'>" . number_format($num2, ($num2 == floor($num2) ? 0 : 2)) . "</span>";
echo "<i class='fas fa-equals text-success mx-2'></i>";
echo "<span class='badge bg-success text-white fs-6'>" . $resultado_formateado . "</span>";
echo "</div>";

if ($resultado > 100) {
    echo "<p class='text-muted mt-2'><i class='text-warning'></i> Resultado superior a 100</p>";
} elseif ($resultado < 0) {
    echo "<p class='text-muted mt-2'><i class='text-info'></i> Resultado negativo</p>";
} else {
    echo "<p class='text-muted mt-2'><i class='text-success'></i> Operación completada</p>";
}

echo "</div>";
?>