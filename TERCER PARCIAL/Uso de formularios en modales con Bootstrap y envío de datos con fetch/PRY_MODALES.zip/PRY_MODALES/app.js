// Funciones utilitarias

// Función para mostrar loading
function mostrarLoading(formId) {
    const form = document.getElementById(formId);
    const loading = form.querySelector('.loading');
    const button = form.querySelector('button[type="submit"]');
    
    loading.classList.add('show');
    button.disabled = true;
}

// Función para ocultar loading
function ocultarLoading(formId) {
    const form = document.getElementById(formId);
    const loading = form.querySelector('.loading');
    const button = form.querySelector('button[type="submit"]');
    
    loading.classList.remove('show');
    button.disabled = false;
}

// Función para mostrar resultado
function mostrarResultado(resultadoId, texto) {
    const resultado = document.getElementById(resultadoId);
    const textoResultado = document.getElementById('texto' + resultadoId.charAt(0).toUpperCase() + resultadoId.slice(1));
    
    textoResultado.innerHTML = texto;
    resultado.classList.remove('hidden');
    resultado.classList.add('fade-in');
}

// Función genérica para enviar formularios
function enviarFormulario(formId, archivo, callback) {
    const form = document.getElementById(formId);
    const formData = new FormData(form);
    
    mostrarLoading(formId);
    
    fetch('php/' + archivo, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        return response.text();
    })
    .then(data => {
        ocultarLoading(formId);
        callback(data);
    })
    .catch(error => {
        ocultarLoading(formId);
        callback('Error: ' + error.message);
    });
}

// Manejadores de eventos para cada formulario

// Manejar formulario de suma
document.getElementById('formSuma').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const numero1 = document.getElementById('numero1').value;
    const numero2 = document.getElementById('numero2').value;
    
    // Validación básica
    if (!numero1 || !numero2) {
        mostrarResultado('resultadoSuma', '<div class="alert alert-danger">Por favor ingresa ambos números</div>');
        return;
    }
    
    const formData = new FormData();
    formData.append('numero1', numero1);
    formData.append('numero2', numero2);
    
    mostrarLoading('formSuma');
    
    fetch('php/suma.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        ocultarLoading('formSuma');
        mostrarResultado('resultadoSuma', data);
    })
    .catch(error => {
        ocultarLoading('formSuma');
        mostrarResultado('resultadoSuma', '<div class="alert alert-danger">Error: ' + error.message + '</div>');
    });
});

// Manejar formulario de tabla
document.getElementById('formTabla').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const numero = document.getElementById('numeroTabla').value;
    
    // Validación básica
    if (!numero) {
        mostrarResultado('resultadoTabla', '<div class="alert alert-danger">Por favor ingresa un número</div>');
        return;
    }
    
    const formData = new FormData();
    formData.append('numero', numero);
    
    mostrarLoading('formTabla');
    
    fetch('php/tabla.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        ocultarLoading('formTabla');
        mostrarResultado('resultadoTabla', data);
    })
    .catch(error => {
        ocultarLoading('formTabla');
        mostrarResultado('resultadoTabla', '<div class="alert alert-danger">Error: ' + error.message + '</div>');
    });
});

// Manejar formulario par/impar
document.getElementById('formParImpar').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const numero = document.getElementById('numeroParImpar').value;
    
    // Validación básica
    if (!numero) {
        mostrarResultado('resultadoParImpar', '<div class="alert alert-danger">Por favor ingresa un número</div>');
        return;
    }
    
    const formData = new FormData();
    formData.append('numero', numero);
    
    mostrarLoading('formParImpar');
    
    fetch('php/par_impar.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        ocultarLoading('formParImpar');
        mostrarResultado('resultadoParImpar', data);
    })
    .catch(error => {
        ocultarLoading('formParImpar');
        mostrarResultado('resultadoParImpar', '<div class="alert alert-danger">Error: ' + error.message + '</div>');
    });
});

// Manejar formulario de edad
document.getElementById('formEdad').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const anio = document.getElementById('anioNacimiento').value;
    
    // Validación básica
    if (!anio) {
        mostrarResultado('resultadoEdad', '<div class="alert alert-danger">Por favor ingresa un año</div>');
        return;
    }
    
    const formData = new FormData();
    formData.append('anio', anio);
    
    mostrarLoading('formEdad');
    
    fetch('php/edad.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        ocultarLoading('formEdad');
        mostrarResultado('resultadoEdad', data);
    })
    .catch(error => {
        ocultarLoading('formEdad');
        mostrarResultado('resultadoEdad', '<div class="alert alert-danger">Error: ' + error.message + '</div>');
    });
});

// Limpiar formularios cuando se abren los modales
document.addEventListener('DOMContentLoaded', function() {
    const modales = ['modalSuma', 'modalTabla', 'modalParImpar', 'modalEdad'];
    
    modales.forEach(modalId => {
        const modal = document.getElementById(modalId);
        modal.addEventListener('show.bs.modal', function() {
            const form = this.querySelector('form');
            const resultado = this.querySelector('.resultado');
            
            // Resetear formulario
            form.reset();
            
            // Ocultar resultado anterior
            if (resultado) {
                resultado.classList.add('hidden');
                resultado.classList.remove('fade-in');
            }
            
            // Asegurar que no hay loading activo
            const loading = form.querySelector('.loading');
            const button = form.querySelector('button[type="submit"]');
            
            if (loading) loading.classList.remove('show');
            if (button) button.disabled = false;
        });
    });
    
    // Agregar efectos de hover a las cards
    const cards = document.querySelectorAll('.card-calculator');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});

// Función para validar números
function validarNumero(valor, nombre) {
    if (!valor) {
        return `Por favor ingresa ${nombre}`;
    }
    
    if (isNaN(valor)) {
        return `${nombre} debe ser un número válido`;
    }
    
    return null;
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const alertClass = tipo === 'error' ? 'alert-danger' : 
                      tipo === 'success' ? 'alert-success' : 
                      tipo === 'warning' ? 'alert-warning' : 'alert-info';
    
    return `<div class="alert ${alertClass}" role="alert">${mensaje}</div>`;
}