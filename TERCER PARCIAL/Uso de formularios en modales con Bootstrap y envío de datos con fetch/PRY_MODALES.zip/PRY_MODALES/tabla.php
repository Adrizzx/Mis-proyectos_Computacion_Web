<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Método no permitido";
    exit;
}

if (!isset($_POST['numero'])) {
    echo "Falta el número requerido";
    exit;
}

$numero = $_POST['numero'];

if (!is_numeric($numero)) {
    echo "Por favor ingresa un número válido";
    exit;
}

$num = intval($numero);

if ($num < -1000 || $num > 1000) {
    echo "Por favor ingresa un número entre -1000 y 1000";
    exit;
}

echo "<div class='text-center'>";
echo "<h4 class='text-primary mb-4'>Tabla de Multiplicar del " . $num . "</h4>";
echo "<div class='table-responsive'>";
echo "<table class='table table-striped table-hover'>";
echo "<thead class='table-primary'>";
echo "<tr><th>Operación</th><th>Resultado</th></tr>";
echo "</thead>";
echo "<tbody>";

for ($i = 1; $i <= 10; $i++) {
    $resultado = $num * $i;
    $clase_fila = "";
    
    if ($i == 5) {
        $clase_fila = "table-warning";
    } elseif ($i == 10) {
        $clase_fila = "table-success";
    }
    
    echo "<tr class='" . $clase_fila . "'>";
    echo "<td class='fw-bold'>" . $num . " × " . $i . "</td>";
    echo "<td class='text-primary fw-bold'>" . number_format($resultado) . "</td>";
    echo "</tr>";
}

echo "</tbody>";
echo "</table>";
echo "</div>";

echo "<div class='mt-3 p-3 bg-light rounded'>";
echo "<small class='text-muted'>";
echo "<i class='fas fa-info-circle me-2'></i>";
echo "Tabla generada para el número <strong>" . $num . "</strong>";
if ($num < 0) {
    echo " (número negativo)";
} elseif ($num == 0) {
    echo " (todos los resultados son cero)";
} elseif ($num == 1) {
    echo " (tabla del 1)";
}
echo "</small>";
echo "</div>";

echo "</div>";
?>