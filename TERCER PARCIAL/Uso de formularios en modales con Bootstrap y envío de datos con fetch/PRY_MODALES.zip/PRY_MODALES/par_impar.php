<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Método no permitido";
    exit;
}

if (!isset($_POST['numero'])) {
    echo "Falta el número requerido";
    exit;
}

$numero = $_POST['numero'];

if (!is_numeric($numero)) {
    echo "Por favor ingresa un número válido";
    exit;
}

$num = intval($numero);
$es_par = ($num % 2) == 0;

echo "<div class='text-center'>";
echo "<h4 class='text-primary mb-4'>Análisis de Paridad</h4>";

echo "<div class='mb-4'>";
echo "<h5>Número analizado:</h5>";
echo "<span class='badge bg-primary fs-3 px-4 py-2'>" . number_format($num) . "</span>";
echo "</div>";

if ($es_par) {
    echo "<div class='alert alert-success' role='alert'>";
    echo "<i class='fas fa-check-circle fs-1 text-success mb-3'></i>";
    echo "<h3 class='text-success mb-3'>ES PAR</h3>";
    echo "<p class='mb-2'>El número <strong>" . number_format($num) . "</strong> es divisible entre 2</p>";
    echo "<small class='text-muted'>Residuo: 0</small>";
    echo "</div>";
} else {
    echo "<div class='alert alert-warning' role='alert'>";
    echo "<i class='fas fa-times-circle fs-1 text-warning mb-3'></i>";
    echo "<h3 class='text-warning mb-3'>ES IMPAR</h3>";
    echo "<p class='mb-2'>El número <strong>" . number_format($num) . "</strong> NO es divisible entre 2</p>";
    echo "<small class='text-muted'>Residuo: 1</small>";
    echo "</div>";
}

echo "</div>";
?>