<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Método no permitido";
    exit;
}

if (!isset($_POST['fecha_nacimiento'])) {
    echo "Falta la fecha requerida";
    exit;
}

$fecha_nacimiento = $_POST['fecha_nacimiento'];

if (empty($fecha_nacimiento)) {
    echo "Por favor ingresa una fecha válida";
    exit;
}

$fecha_nac = new DateTime($fecha_nacimiento);
$fecha_actual = new DateTime();

if ($fecha_nac > $fecha_actual) {
    echo "La fecha de nacimiento no puede ser mayor a la fecha actual";
    exit;
}

$diferencia = $fecha_actual->diff($fecha_nac);
$años = $diferencia->y;
$meses = $diferencia->m;
$dias = $diferencia->d;

echo "<div class='text-center'>";
echo "<h4 class='text-primary mb-4'>Cálculo de Edad</h4>";

echo "<div class='row mb-4'>";
echo "<div class='col-md-6'>";
echo "<div class='card border-primary'>";
echo "<div class='card-body'>";
echo "<h6 class='card-title text-primary'>Fecha Nacimiento</h6>";
echo "<h5 class='text-primary'>" . $fecha_nac->format('d/m/Y') . "</h5>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "<div class='col-md-6'>";
echo "<div class='card border-success'>";
echo "<div class='card-body'>";
echo "<h6 class='card-title text-success'>Fecha Actual</h6>";
echo "<h5 class='text-success'>" . $fecha_actual->format('d/m/Y') . "</h5>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<div class='alert alert-info' role='alert'>";
echo "<i class='fas fa-birthday-cake fs-1 text-info mb-3'></i>";
echo "<h2 class='text-info mb-3'>Edad: <strong>" . $años . " años, " . $meses . " meses, " . $dias . " días</strong></h2>";
echo "<p>Fecha de nacimiento: <strong>" . $fecha_nac->format('d/m/Y') . "</strong></p>";
echo "</div>";

echo "</div>";
?>