<?php 

    require_once '../conexion/db.php';
    
    $id = $_POST['id'];

    
    $consulta = "DELETE FROM usuarios WHERE id = :id";
    $stmt = $pdo->prepare($consulta);
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    echo json_encode(['success' => true]);


?>