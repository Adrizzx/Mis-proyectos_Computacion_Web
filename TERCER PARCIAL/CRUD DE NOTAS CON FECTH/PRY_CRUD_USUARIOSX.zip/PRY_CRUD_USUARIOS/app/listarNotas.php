<?php
// conexion a base de datos con conexion/db.php
require_once '../conexion/db.php';

// consultar las notas con JOIN para obtener nombres de usuarios y materias
$sql = "SELECT usuarios.nombre as nombre_usuario,
               materias.nombre as nombre_materia,
               materias.nrc, n1, n2, n3, promedio 
        FROM notas
        JOIN usuarios ON notas.usuario_id = usuarios.id
        JOIN materias ON notas.materia_id = materias.id
        ORDER BY usuarios.nombre, materias.nombre";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$notas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LISTA DE NOTAS</title>
    <link rel="stylesheet" href="../public/bootstrap/css/bootstrap.min.css">
    <script src="../public/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container py-5">
        <div class="card shadow-sm">
            <div class="card-body">
                <h1 class="text-center mb-4 text-primary">LISTA DE NOTAS</h1>
                
                <div class="mb-3">
                </div>

                <?php if(count($notas) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Estudiante</th>
                                <th>Materia</th>
                                <th>NRC</th>
                                <th>Nota 1</th>
                                <th>Nota 2</th>
                                <th>Nota 3</th>
                                <th>Promedio</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($notas as $nota): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($nota['nombre_usuario']); ?></td>
                                <td><?php echo htmlspecialchars($nota['nombre_materia']); ?></td>
                                <td><?php echo htmlspecialchars($nota['nrc']); ?></td>
                                <td><?php echo number_format($nota['n1'], 2); ?></td>
                                <td><?php echo number_format($nota['n2'], 2); ?></td>
                                <td><?php echo number_format($nota['n3'], 2); ?></td>
                                <td class="fw-bold"><?php echo number_format($nota['promedio'], 2); ?></td>
                                <td>
                                    <?php if($nota['promedio'] >= 14): ?>
                                        <span class="badge bg-success">APROBADO</span>
                                    <?php else: ?>
                        
                                    
                                        <span class="badge bg-danger">REPROBADO</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>


                <?php else: ?>
                <div class="alert alert-info text-center">
                    <h4>No hay notas registradas</h4>
                    <p>Aún no se han ingresado notas en el sistema.</p>
                    <a href="ingresarNotas.php" class="btn btn-success">Ingresar Primera Nota</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
