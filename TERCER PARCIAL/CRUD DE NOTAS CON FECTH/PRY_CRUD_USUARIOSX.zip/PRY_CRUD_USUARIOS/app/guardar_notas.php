<?php
require_once '../conexion/db.php';

$usuario_id = $_POST['usuario_id'];
$materia_id = $_POST['materia_id'];

$nota_1 = $_POST['n1'];
$nota_2 = $_POST['n2'];
$nota_3 = $_POST['n3'];

$promedio = ($nota_1 + $nota_2 + $nota_3) / 3;

$sql = $pdo->prepare(
    "INSERT INTO notas (usuario_id, materia_id, n1, n2, n3, promedio) 
    VALUES (:u_id, :m_id, :n1, :n2, :n3, :promedio)"
);

$sql->bindParam(':u_id', $usuario_id);
$sql->bindParam(':m_id', $materia_id);
$sql->bindParam(':n1', $nota_1);
$sql->bindParam(':n2', $nota_2);
$sql->bindParam(':n3', $nota_3);
$sql->bindParam(':promedio', $promedio);

$sql->execute();
    echo "Notas guardadas exitosamente";

?>
