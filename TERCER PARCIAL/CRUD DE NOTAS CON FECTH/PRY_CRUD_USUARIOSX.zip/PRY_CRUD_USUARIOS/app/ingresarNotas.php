<?php
// conexion a base de datos con conexion/db.php
require_once '../conexion/db.php';
// consultar los usuarios de la base de datos
$sql = "SELECT * FROM usuarios";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

//consultar las materias de la base de datos 
$sqlMaterias = "SELECT * FROM materias";
$stmtMaterias = $pdo->prepare($sqlMaterias);
$stmtMaterias->execute();
$Materias = $stmtMaterias->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INGRESAR NOTAS</title>
    <link rel="stylesheet" href="../public/bootstrap/css/bootstrap.min.css">
     <script src="../public/bootstrap/js/bootstrap.min.js"></script>
         <script src="https://cdn.jsdelivr.net/npm/@magicbruno/swalstrap5@1.0.8/dist/js/swalstrap5_all.min.js"></script>

</head>
<body>
    
    <div class="container py-5">
            <div class="card-body">
                <h1 class="text-center mb-4">INGRESAR NOTAS</h1>



                <form id ="formGuardarNotas"  >
                    <div class="mb-3">
                        <label for="usuario_id" class="form-label">SELECCIONAR USUARIOS</label>
                        <select name="usuario_id" id="usuario" class="form-select">
                            <?php foreach ($usuarios as $user): ?>
                                <option value="<?php echo $user['id'];?>">
                                    <?php echo $user['nombre']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>


                        <label for="materia_id" class="form-label">SELECCIONAR MATERIAS</label>
                        <select name="materia_id" id="materia" class="form-select">
                            <?php foreach ($Materias as $materia): ?>
                                <option value="<?php echo $materia['id'];?>">
                                    <?php echo $materia['nombre']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="n1" class="form-label">NOTA 1</label>
                            <input type="number" step="0.01" min="0" max="20" name="n1" id="n1" class="form-control" placeholder="0.00">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="n2" class="form-label">NOTA 2</label>
                            <input type="number" step="0.01" min="0" max="20" name="n2" id="n2" class="form-control" placeholder="0.00">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="n3" class="form-label">NOTA 3</label>
                            <input type="number" step="0.01" min="0" max="20" name="n3" id="n3" class="form-control" placeholder="0.00">
                        </div>
                    </div>

                    <div class="mb-3">
                        
                        <button type="submit" class="btn btn-success">GUARDAR NOTAS</button>
                        

                    </div>
                </form>
            </div>
        </div>

        <script>
            const formGuardarNotas = document.getElementById('formGuardarNotas');

            formGuardarNotas.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                
                fetch('guardar_notas.php', {
                    method: 'POST',
                    body: formData
                })
                .then(function(response) {
                    return response.text();
                })
                .then(function(data) {
                    Swal.fire({
                        title: '¡Éxito!',
                        text: 'Las notas se guardaron correctamente',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formGuardarNotas.reset();
                        }
                    });
                })
                .catch(function(error) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Hubo un problema al guardar las notas',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                });
            });
        </script>

        
</body>
</html>

