CREATE TABLE usuarios(
	id int AUTO_INCREMENT PRIMARY KEY,
    nombre varchar(255),
    email varchar(255),
    edad int
);
CREATE TABLE materias(
	id int AUTO_INCREMENT PRIMARY KEY,
    nombre varchar(255) NOT NULL,
    nrc varchar(10) NOT NULL
);
CREATE TABLE notas (
    id int AUTO_INCREMENT PRIMARY KEY,
    usuario_id int NOT NULL,
    materia_id int NOT NULL,
    n1 decimal(5,2) NOT NULL,
    n2 decimal(5,2) NOT NULL,
    n3 decimal(5,2) NOT NULL,
    promedio decimal(5,2) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
);

SELECT usuarios.nombre as nombre_usuario,
 materias.nombre as nombre_materia,
  materias.nrc,n1,n2,n3,promedio 
  FROM notas
JOIN  usuarios on notas.usuario_id=usuarios.id
JOIN  materias on notas.materia_id=materias.id
