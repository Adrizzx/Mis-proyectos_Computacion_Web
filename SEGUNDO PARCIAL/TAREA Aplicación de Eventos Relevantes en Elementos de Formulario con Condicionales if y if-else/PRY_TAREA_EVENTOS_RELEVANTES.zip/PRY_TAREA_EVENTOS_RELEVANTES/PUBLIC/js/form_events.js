function manejarTexto(input) {
  let res = document.getElementById("resText");
  let valor = input.value;
  if (valor.length === 0) {
    res.innerHTML = "Campo vacío";
    res.className = "error";
  } else {
    res.innerHTML = `Texto: ${valor}`;
    res.className = "info";
  }
}
function cambioTexto(input) {
  let res = document.getElementById("resText");
  res.innerHTML = "Texto cambiado";
  res.className = "success";
}
function focoTexto(input) {
  let res = document.getElementById("resText");
  res.innerHTML = "Campo enfocado";
  res.className = "info";
}
function blurTexto(input) {
  let res = document.getElementById("resText");
  if (input.value.trim() === "") {
    res.innerHTML = "Campo vacio";
    res.className = "error";
  }
}
function teclaTexto(input) {
  let res = document.getElementById("resText");
  res.innerHTML = "Tecla presionada";
  res.className = "info";
}

function manejarEmail(input) {
  let res = document.getElementById("resEmail");
  res.innerHTML = `Email: ${input.value}`;
  res.className = "info";
}
function cambioEmail(input) {
  let res = document.getElementById("resEmail");
  res.innerHTML = "Email cambiado";
  res.className = "success";
}
function blurEmail(input) {
  let res = document.getElementById("resEmail");
  if (input.value.trim() === "") {
    res.innerHTML = "Campo vacio";
    res.className = "error";
  }
}

function manejarNumero(input) {
  let res = document.getElementById("resNumber");
  res.innerHTML = `Número actual: ${input.value}`;
  res.className = "info";
}
function cambioNumero(input) {
  let res = document.getElementById("resNumber");
  res.innerHTML = "Número cambiado";
  res.className = "success";
}
function verificarEdad(input) {
  let edad = parseInt(input.value);
  let res = document.getElementById("resNumber");
  if (edad >= 18) {
    res.innerHTML = "Mayor de edad";
    res.className = "success";
  } else {
    res.innerHTML = "Menor de edad";
    res.className = "error";
  }
}

function escribirPassword(input) {
  let res = document.getElementById("resPassword");
  res.innerHTML = "Escribiendo contraseña...";
  res.className = "info";
}
function evaluarPassword(input) {
  let res = document.getElementById("resPassword");
  if (input.value.length < 6) {
    res.innerHTML = "Contraseña débil";
    res.className = "error";
  } else {
    res.innerHTML = "Contraseña segura";
    res.className = "success";
  }
}
function blurPassword(input) {
  let res = document.getElementById("resPassword");
  if (input.value.trim() === "") {
    res.innerHTML = "Campo vacio";
    res.className = "error";
  }
}

function cambioFecha(input) {
  let res = document.getElementById("resDate");
  res.innerHTML = `Fecha: ${input.value}`;
  res.className = "success";
}
function focoFecha(input) {
  let res = document.getElementById("resDate");
  res.innerHTML = "Fecha";
  res.className = "info";
}
function blurFecha(input) {
  let res = document.getElementById("resDate");
  if (input.value.trim() === "") {
    res.innerHTML = "Fecha vacia";
    res.className = "error";
  }
}

function cambioHora(input) {
  let res = document.getElementById("resTime");
  let hora = parseInt(input.value.split(":"));
  if (hora < 12) {
    res.innerHTML = "Buenos días";
    res.className = "success";
  } else {
    res.innerHTML = "Buenas tardes";
    res.className = "info";
  }
}
function blurHora(input) {
  let res = document.getElementById("resTime");
  if (input.value.trim() === "") {
    res.innerHTML = "Hora vacIa";
    res.className = "error";
  }
}

function cambioArchivo(input) {
  let res = document.getElementById("resFile");
  res.innerHTML = `Archivo: ${input.files[0]?.name || 'Ninguno'}`;
  res.className = "success";
}
function clickArchivo(input) {
  let res = document.getElementById("resFile");
  res.innerHTML = "Seleccionando archivo...";
  res.className = "info";
}
function blurArchivo(input) {
  let res = document.getElementById("resFile");
  if (input.files.length === 0) {
    res.innerHTML = "Archivo vacio";
    res.className = "error";
  }
}

function moverRango(input) {
  let res = document.getElementById("resRange");
  res.innerHTML = `Valor actual: ${input.value}`;
  res.className = "info";
}
function cambioRango(input) {
  let res = document.getElementById("resRange");
  res.innerHTML = `Rango cambiado: ${input.value}`;
  res.className = "success";
}

function seleccionarColor(input) {
  let res = document.getElementById("resColor");
  res.innerHTML = `Color seleccionado: ${input.value}`;
  res.className = "info";
}
function confirmarColor(input) {
  let res = document.getElementById("resColor");
  res.innerHTML = `Color confirmado: ${input.value}`;
  res.className = "success";
}

function escribirTelefono(input) {
  let res = document.getElementById("resTel");
  res.innerHTML = `Tel ingresado: ${input.value}`;
  res.className = "info";
}
function validarTelefono(input) {
  let res = document.getElementById("resTel");
  if (input.value.length >= 8) {
    res.innerHTML = "Teléfono válido";
    res.className = "success";
  } else {
    res.innerHTML = "Número incompleto";
    res.className = "error";
  }
}

function escribirUrl(input) {
  let res = document.getElementById("resUrl");
  res.innerHTML = `URL escribiendo...`;
  res.className = "info";
}
function blurUrl(input) {
  let res = document.getElementById("resUrl");
  if (input.value.trim() === "") {
    res.innerHTML = `URL vacío`;
    res.className = "error";
  }
}

function manejarCheckbox() {
  let cb1 = document.getElementById("cb1");
  let cb2 = document.getElementById("cb2");
  let seleccionados = [cb1, cb2].filter(c => c.checked).map(c => c.value);
  let res = document.getElementById("resCheckbox");
  res.innerHTML = `Seleccionado: ${seleccionados.join(", ")}`;
  res.className = "info";
}

function seleccionarRadio(input) {
  let res = document.getElementById("resRadio");
  res.innerHTML = `Sexo: ${input.value}`;
  res.className = "success";
}

function cambioSelect(input) {
  let res = document.getElementById("resSelect");
  if (input.value === "") {
    res.innerHTML = "Seleccione un país";
    res.className = "error";
  } else {
    res.innerHTML = `País seleccionado: ${input.value}`;
    res.className = "success";
  }
}
function clickSelect(input) {
  let res = document.getElementById("resSelect");
  res.innerHTML = "Desplegando opciones...";
  res.className = "info";
}
function focoSelect(input) {
  let res = document.getElementById("resSelect");
  res.innerHTML = "En select";
  res.className = "info";
}
function blurSelect(input) {
  let res = document.getElementById("resSelect");
  if (input.value === "") {
    res.innerHTML = "Select vacio";
    res.className = "error";
  }
}

function escribirComentario(input) {
  let res = document.getElementById("resTextarea");
  res.innerHTML = `Escribiendo comentario...`;
  res.className = "info";
}
function contarPalabras(input) {
  let palabras = input.value.trim().split(/\s+/).length;
  let res = document.getElementById("resTextarea");
  res.innerHTML = `Palabras: ${palabras}`;
  res.className = "info";
}
function focoTextarea(input) {
  let res = document.getElementById("resTextarea");
  res.innerHTML = `En comentario`;
  res.className = "info";
}
function blurTextarea(input) {
  let res = document.getElementById("resTextarea");
  if (input.value.trim() === "") {
    res.innerHTML = "Comentario vacio";
    res.className = "error";
  }
}

function clickBoton(btn) {
  let res = document.getElementById("resForm");
  res.innerHTML = "Botón clickeado";
  res.className = "success";
}
function hoverBoton(btn) {
  let res = document.getElementById("resForm");
  res.innerHTML = "Mouse sobre el botón";
  res.className = "info";
}
function presionarBoton(btn) {
  let res = document.getElementById("resForm");
  res.innerHTML = "Mouse presionado";
  res.className = "info";
}
function soltarBoton(btn) {
  let res = document.getElementById("resForm");
  res.innerHTML = "Mouse soltado";
  res.className = "info";
}
function focoBoton(btn) {
  let res = document.getElementById("resForm");
  res.innerHTML = "En botón";
  res.className = "info";
}

function enviarFormulario(form) {
  let res = document.getElementById("resForm");
  res.innerHTML = "Formulario enviado";
  res.className = "success";
}
function resetFormulario(form) {
  let res = document.getElementById("resForm");
  res.innerHTML = "Formulario reiniciado";
  res.className = "error";
}