function guardarDatosUsuario() {
    // Obtener los valores de los campos del formulario
    var usuario_nombre = document.getElementById('txt_nombre').value;
    var usuario_apellido = document.getElementById('txt_apellido').value;
    var usuario_cedula = document.getElementById('txt_cedula').value;

    // Validar que los campos no estén vacíos
    if(!usuario_nombre || !usuario_apellido || !usuario_cedula) {
        alert('Por favor complete todos los campos');
        return;
    }

    // Crear un objeto con los datos del usuario
    var datos_Usuario = {
        nombre_usuarios: usuario_nombre,
        apellido_usuarios: usuario_apellido,
        cedula_usuarios: usuario_cedula
    };

    // Guardar en localStorage
    localStorage.setItem('datos_usuario', JSON.stringify(datos_Usuario));
    alert('Datos guardados correctamente');
    window.location.href = 'ver_datos_usuario.html';
}