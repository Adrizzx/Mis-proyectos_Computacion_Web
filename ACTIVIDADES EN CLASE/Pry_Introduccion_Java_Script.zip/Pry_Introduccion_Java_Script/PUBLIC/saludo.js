function saludar() {
    let saludo = document.getElementById("mostrar_saludo");
    saludo.textContent = "SALUDANDO DESDE EL BOTON MEDIANTE CLICK";
}



