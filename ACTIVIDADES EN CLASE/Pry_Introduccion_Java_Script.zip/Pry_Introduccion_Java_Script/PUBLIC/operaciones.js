
function calcular_suma() {
   let n1 = document.getElementById("txt_primer_numero").value;
let n2 = document.getElementById("txt_segundo_numero").value;
  let res = parseFloat(n1) + parseFloat(n2);

    document.getElementById("suma_resultado").textContent = "Resultado: " + res;
}


function calcular_resta() {
let n1 = document.getElementById("txt_primer_numero_rest").value;
  let n2 = document.getElementById("txt_segundo_numero_rest").value;
let res = parseFloat(n1) - parseFloat(n2);

    document.getElementById("resta_resultado").textContent = "Resultado: " + res;
}


function calcular_multiplicacion() {
    let n1 = document.getElementById("txt_primer_numero_mult").value;
let n2 = document.getElementById("txt_segundo_numero_mult").value;
 let res = parseFloat(n1) * parseFloat(n2);

    document.getElementById("multiplicacion_resultado").textContent = "Resultado: " + res;
}


function calcular_division() {
    let n1 = document.getElementById("txt_primer_numero_div").value;
 let n2 = document.getElementById("txt_segundo_numero_div").value;
    if (n2 != 0) {
      let res = parseFloat(n1) / parseFloat(n2);
      
        document.getElementById("division_resultado").textContent = "Resultado que dio " + res;
 } else {

      document.getElementById("division_resultado").textContent = "No se divide para00";
    }
}



