let variable1 = '';
let variable2 = '';
let operador = '';

function enviarValor(boton) {
    const valor = boton.getAttribute('data-valor');
    const caja = document.getElementById('txt_caja_texto');

    caja.value += valor;
}

function enviarOperacion(boton) {
    const caja = document.getElementById('txt_caja_texto');
    variable1 = caja.value;
    operador = boton.getAttribute('data-valor');
    caja.value = '';
}

function calcularResultado() {
    const caja = document.getElementById('txt_caja_texto');
    variable2 = caja.value;

    let resultado = 0;
    if (operador === '+') {
        resultado = parseFloat(variable1) + parseFloat(variable2);
    } else if (operador === '-') {
        resultado = parseFloat(variable1) - parseFloat(variable2);
    } else if (operador === '*') {
        resultado = parseFloat(variable1) * parseFloat(variable2);
    } else if (operador === '/') {
        resultado = parseFloat(variable1) / parseFloat(variable2);
    }

    console.log(`Resultado: ${resultado}`);
    caja.value = resultado;
}

function borrarTodo() {
    variable1 = '';
    variable2 = '';
    operador = '';
    document.getElementById('txt_caja_texto').value = '';
}