function mostrar(seccionId) {
  // Oculta todas las secciones
  const secciones = document.querySelectorAll('.seccion');
  secciones.forEach(seccion => {
    seccion.classList.add('d-none');
  });

  // Muestra solo la sección seleccionada
  document.getElementById(seccionId).classList.remove('d-none');
}
